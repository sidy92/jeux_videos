using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class trajectoire : MonoBehaviour
{
    public Transform spawnball;
    public float speed = 25f;
    public float lifespan =  10f;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        this.transform.Translate(0,speed* Time.deltaTime,0);
        Destroy(this.gameObject,lifespan);
    }
}