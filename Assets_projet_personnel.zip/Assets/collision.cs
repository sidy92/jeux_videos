using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class collision : MonoBehaviour {

    private void OnTriggerEnter(Collider other){
        Debug.Log("hit detected");
        Destroy(other.gameObject);
        this.gameObject.SetActive(false);
    }
}
