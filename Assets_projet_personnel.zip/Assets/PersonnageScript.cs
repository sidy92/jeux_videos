using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PersonnageScript : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        /*
        this.transform.position = new Vector3 (this.transform.position.x, this.transform.position.y, this.transform.position.z + this.zOffset);

        this.transform.Translate(0, -1 * Time.deltaTime, 0);
        if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            transform.position += new Vector3(-1, 0, 0);
        }
        else if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            transform.position += new Vector3(1, 0, 0);
        }*/
    }



    void FixedUpdate() {
        transform.Translate(Vector3.forward * 3f * Time.fixedDeltaTime * Input.GetAxis("Horizontal"));
        transform.Translate(Vector3.right * 3f * Time.fixedDeltaTime * Input.GetAxis("Vertical"));
    }
}
