using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bot : MonoBehaviour
{
    public float speed = 5f;
    public float angle = 30f;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        this.transform.Translate(0,0,speed * Time.deltaTime);
        this.transform.rotation *= (Quaternion.AngleAxis(angle * Time.deltaTime,Vector3.up));
    }
}