using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class shoot : MonoBehaviour
{
    public GameObject balleprefab;
    public Transform spawnball;
    private GameObject balle;
    public float speed = 10f;
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetButtonDown ("Fire1"))
        {
            this.balleprefab.SetActive(true);
            balle = Instantiate(this.balleprefab,this.spawnball.transform.position, this.transform.rotation);
            balle.AddComponent<destruction>();
            this.balleprefab.SetActive(false);
        }
    }
}
